function shownames() {
    
document.getElementById('names').innerText= 'Rudra & Sanket';
console.log('Clicked on show devs')
}